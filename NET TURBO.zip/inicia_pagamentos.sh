#!/bin/bash
dir=$(pwd)
while true; do php $dir/processos/pagamentos.php; done;